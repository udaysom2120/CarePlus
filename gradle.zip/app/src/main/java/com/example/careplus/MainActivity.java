package com.example.careplus;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    TextView rateCount;
    Button submit;
    EditText Feedback;
    RatingBar ratingStars;
    CheckBox Check;
    float rateValue;

    @SuppressLint("SetTextI18n")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Feedback= findViewById(R.id.EditText_FeedbackBody);
        Check= (CheckBox) findViewById (R.id.CheckBoxResponse);
        submit= (Button) findViewById(R.id.ButtonSendFeedback);
        rateCount= findViewById(R.id.rateCount);
        ratingStars=(RatingBar) findViewById(R.id.ratingbar);

        ratingStars.setOnRatingBarChangeListener((ratingStars, rating, fromUser) -> {


            rateValue = ratingStars.getRating();
            if (rateValue==0)
                rateCount.setText("No Rating"+rateValue+ " /5");
            else if (rateValue <= 1 && rateValue >0)
                rateCount.setText("Dissatisfied " + rateValue + " /5");
            else if (rateValue <= 2 && rateValue > 1)
                rateCount.setText("Poor " + rateValue + " /5");
            else if (rateValue <= 3 && rateValue > 2)
                rateCount.setText("Average " + rateValue + " /5");
            else if (rateValue <= 4 && rateValue > 3)
                rateCount.setText("Satisfied" + rateValue + " /5");
            else if (rateValue <= 5 && rateValue > 4)
                rateCount.setText("Best" + rateValue + " /5");




        });




        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getApplicationContext(),"Thanks! Your Feedback is Submitted",Toast.LENGTH_SHORT).show();


            }
        });


    }
}