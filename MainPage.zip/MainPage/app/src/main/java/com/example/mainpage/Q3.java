package com.example.mainpage;

import androidx.appcompat.app.AppCompatActivity;

import android.animation.Animator;
import android.os.Bundle;
import android.view.View;
import android.view.animation.DecelerateInterpolator;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class Q3 extends AppCompatActivity {
    private TextView Question;
    private LinearLayout options_container;
    private Button Next;
    private int count=0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_q3);

        Question=(TextView)findViewById(R.id.Question);
        options_container=(LinearLayout)findViewById(R.id.options_container);
        Next=(Button)findViewById(R.id.Next);

        List<QuestionModel>list=new ArrayList<>();
        list.add(new QuestionModel("question1","a","b","c","d","a"));
        list.add(new QuestionModel("question2","a","b","c","d","a"));
        list.add(new QuestionModel("question3","a","b","c","d","d"));
        list.add(new QuestionModel("question4","a","b","c","d","a"));
        list.add(new QuestionModel("question5","a","b","c","d","c"));

        Next.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                count=0;
                playAnim(Question, 0);
            }

        });

    }

    private void playAnim(View view,int value){
        view.animate().alpha(value).scaleX(value).scaleY(value).setDuration(500).setStartDelay(100).setInterpolator(new DecelerateInterpolator()).setListener(new Animator.AnimatorListener() {
            @Override
            public void onAnimationStart(Animator animation) {
                if(value==0 && count<4){
                    playAnim(options_container.getChildAt(count), 0);
                    count++;
                }
            }

            @Override
            public void onAnimationEnd(Animator animation) {
                if(value==0){
                    playAnim(view,1);
                }
            }

            @Override
            public void onAnimationCancel(Animator animation) {

            }

            @Override
            public void onAnimationRepeat(Animator animation) {

            }
        });
    }


}